Node labels:		[chem]

Edge labels:		[valence]

Node labels were converted to integer values using this map:

Component 0:
	0	C
	1	O
	2	Cl
	3	H
	4	N
	5	F
	6	Br
	7	S
	8	P
	9	I
	10	Na
	11	K
	12	Li
	13	Ca



Edge labels were converted to integer values using this map:

Component 0:
	0	1
	1	2
	2	3



Class labels were converted to integer values using this map:

	0	mutagen
	1	nonmutagen


