import torch
import copy

from tqdm import tqdm
from torch_geometric.loader.dataloader import DataLoader


def filter_correct_data_batch(model, dataset, loader, flag='training', batch_size=3):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    graph_mask = []
    for g in tqdm(iter(loader), total=len(loader)):
        g.to(device)
        model(g.x, g.edge_index, g.edge_attr, g.batch)

        tmp = (g.y == model.readout.argmax(dim=1))
        graph_mask += tmp.int().tolist()  # 将Boolean Tensor->int Tensor

    graph_mask = torch.BoolTensor(graph_mask)

    shuffle_flag = False
    if flag == 'training':
        shuffle_flag = True

    loader = DataLoader(dataset[graph_mask], batch_size=batch_size, shuffle=shuffle_flag)
    print("number of graphs in the %s:%4d" % (flag, sum(graph_mask)))
    return dataset, loader


def relabel_graph(graph, selection):
    subgraph = copy.deepcopy(graph)

    # 根据selection，更新子图的边索引，边属性
    subgraph.edge_index = graph.edge_index.T[selection].T
    subgraph.edge_attr = graph.edge_attr[selection]

    # 获取子图中出现过的所有节点
    sub_nodes = torch.unique(subgraph.edge_index)
    # 更新子图节点特征
    subgraph.x = graph.x[sub_nodes]
    # 更新子图的批处理标识
    subgraph.batch = graph.batch[sub_nodes]

    row, col = graph.edge_index
    node_index = row.new_full((graph.num_nodes, ), -1)
    node_index[sub_nodes] = torch.arange(sub_nodes.size(0), device=row.device)
    subgraph.edge_index = node_index[subgraph.edge_index]

    return subgraph


def insert_multiple_positions(tensor, insert_indices, value):
    if isinstance(insert_indices, list):
        # 如果 insert_indices 是列表，处理每个索引
        for i, index in enumerate(insert_indices):
            index = int(index)  # 确保 index 是整数
            tensor = torch.cat((tensor[:index + i], torch.tensor([value], device=tensor.device), tensor[index + i:]))
    elif isinstance(insert_indices, int):
        # 如果 insert_indices 是单个整数
        index = int(insert_indices)  # 确保 index 是整数
        tensor = torch.cat((tensor[:index], torch.tensor([value], device=tensor.device), tensor[index:]))

    return tensor



