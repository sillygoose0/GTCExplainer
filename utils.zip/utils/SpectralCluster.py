from typing import Callable, Optional, Union
import networkx as nx
import numpy as np
import torch
import torch_sparse
from communities.algorithms import louvain_method
from torch import Tensor
from torch_scatter import scatter_add
from torch_geometric.loader.dataloader import DataLoader
from sklearn.cluster import SpectralClustering, KMeans
from torch_geometric.data import Data
from torch_geometric.utils import degree, to_dense_adj, scatter, cumsum
from torch_geometric.nn.conv import GCNConv
from torch_geometric.nn.pool.connect.filter_edges import filter_adj

from Exist_Model.gnn_model_pool.mutag_gine import MutagNet
from Exist_Model.data_loader_pool.muatg_dataloader import Mutagen
from Exist_Model.gnn_model_pool.mutag_gine import par_args
from utils import set_seed

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# dataset_name = 'mutag'
# path = '../params/%s_net_1.pt' % dataset_name
# model = torch.load(path)
# model = model.to(device)
# model.eval()
#
# args = par_args()
# set_seed(0)
#
# train_dataset = Mutagen(args.data_path, mode='training')
# train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False)


# def topk(
#     x: Tensor,
#     ratio: Optional[Union[float, int]],
#     batch: Tensor,
#     min_score: Optional[float] = None,
#     tol: float = 1e-7,
# ) -> Tensor:
#     if min_score is not None:
#         # Make sure that we do not drop all nodes in a graph.
#         scores_max = scatter(x, batch, reduce='max')[batch] - tol
#         scores_min = scores_max.clamp(max=min_score)
#
#         perm = (x > scores_min).nonzero().view(-1)
#         return perm
#
#     if ratio is not None:
#         num_nodes = scatter(batch.new_ones(x.size(0)), batch, reduce='sum')
#
#         if ratio >= 1:
#             k = num_nodes.new_full((num_nodes.size(0), ), int(ratio))
#         else:
#             k = (float(ratio) * num_nodes.to(x.dtype)).ceil().to(torch.long)
#
#         x, x_perm = torch.sort(x.view(-1), descending=True)
#         batch = batch[x_perm]
#         batch, batch_perm = torch.sort(batch, descending=False, stable=True)
#
#         arange = torch.arange(x.size(0), dtype=torch.long, device=x.device)
#         ptr = cumsum(num_nodes)
#         batched_arange = arange - ptr[batch]
#         mask = batched_arange < k[batch]
#
#         return x_perm[batch_perm[mask]]
#
#
# class SAGPool(torch.nn.Module):
#     def __init__(self, in_channels, ratio=0.8, non_linearity=torch.tanh):
#         super(SAGPool, self).__init__()
#         self.in_channels = in_channels
#         self.ratio = ratio
#         self.score_layer = GCNConv(in_channels, 1)
#         self.non_linearity = non_linearity
#
#     def forward(self, x, edge_index, edge_attr=None, batch=None):
#         if batch is None:
#             batch = edge_index.new_zeros(x.size(0))
#         #x = x.unsqueeze(-1) if x.dim() == 1 else x
#         score = self.score_layer(x,edge_index).squeeze()
#
#         perm = topk(score, self.ratio, batch)
#         x = x[perm] * self.non_linearity(score[perm]).view(-1, 1)
#         batch = batch[perm]
#         edge_index, edge_attr = filter_adj(
#             edge_index, edge_attr, perm, num_nodes=score.size(0))
#
#         return x, edge_index, edge_attr, batch, perm


def compute_batch_laplacian(edge_index, batch):
    num_nodes = batch.size(0)  # 批量图中的节点总数
    # nodes_per_graph = torch.bincount(batch)  # 每张图中的节点数目
    num_graphs = batch.max().item() + 1  # 这一批次中图的数目

    node_degree = degree(edge_index[0], num_nodes=num_nodes)  # 计算每个点的度数

    all_laplacian = []
    for j in range(num_graphs):
        mask_node = batch == j
        nodes_pre_graph = mask_node.sum().item()

        degrees_in_graph = node_degree[mask_node]
        degrees = torch.diag(degrees_in_graph)

        node_in_batch = (batch == j).nonzero(as_tuple=False).view(-1)
        mask_edge = (edge_index[0].unsqueeze(1) == node_in_batch).any(dim=1) & (edge_index[1].unsqueeze(1) == node_in_batch).any(dim=1)

        mask_edge_index = edge_index[:, mask_edge]
        node_index_map = {old_idx: new_idx for new_idx, old_idx in enumerate(node_in_batch.tolist())}
        edge_index_map = torch.clone(mask_edge_index)  # 创建边索引的副本
        edge_index_map[0] = torch.tensor([node_index_map[idx.item()] for idx in mask_edge_index[0]])
        edge_index_map[1] = torch.tensor([node_index_map[idx.item()] for idx in mask_edge_index[1]])

        adj = to_dense_adj(edge_index_map, max_num_nodes=nodes_pre_graph)[0].to(device)

        degrees[degrees == 0] = 1
        degrees = degrees.to(device)
        # degrees_sqrt = np.diag(1.0 / np.sqrt(adj.sum(dim=1)))
        # degrees_sqrt = torch.tensor(degrees_sqrt)
        # laplacian = torch.eye(adj.shape[0]) - degrees_sqrt @ adj @ degrees_sqrt

        assert degrees.shape == adj.shape, f"AssertionError: Shape mismatch at iteration {j}: degrees shape {degrees.shape}, adj shape {adj.shape}"

        laplacian = degrees - adj

        all_laplacian.append(laplacian)

    return all_laplacian


def build_batch_adj(graph):
    adjacency_matrices = []
    for act_graph in graph.to_data_list():
        edge_index = act_graph.edge_index

        adjacency_matrix = torch_sparse.SparseTensor(row=edge_index[0], col=edge_index[1],
                                                     value=torch.ones(edge_index.shape[1]).to(device))
        adjacency_matrices.append(adjacency_matrix)

    return adjacency_matrices


def spectral_cluster(graph, model, n_clusters=2):

    spectral = SpectralClustering(n_clusters=n_clusters, affinity='precomputed', random_state=42)
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)

    laplacian_batch = compute_batch_laplacian(graph.edge_index, graph.batch)

    cluster_labels_batch = []
    for i in range(graph.y.size(0)):
        L = laplacian_batch[i].to(device)

        epsilon = 1e-5  # 小的正则化项
        L += epsilon * torch.eye(L.size(0)).to(device)
        eigenvalues, eigenvectors = torch.linalg.eigh(L)
        embedding = eigenvectors[:, :n_clusters]

        # cluster_labels = spectral.fit_predict(L.cpu().numpy())
        cluster_labels = kmeans.fit_predict(embedding.cpu().numpy())
        cluster_labels = torch.tensor(cluster_labels).to(device)
        cluster_labels_batch.append(cluster_labels)

    graph_node_labels = torch.full((graph.batch.size(0),), -1).to(device)
    pre_node_num = 0
    for graph_index, cluster_labels in enumerate(cluster_labels_batch):
        for i in range(n_clusters):
            node_indices = torch.where(cluster_labels == i)[0]
            node_indices = node_indices.to(graph.edge_index.device)
            node_indices = node_indices + pre_node_num

            edge_index_0_in = torch.isin(graph.edge_index[0], node_indices)
            edge_index_1_in = torch.isin(graph.edge_index[1], node_indices)
            mask = edge_index_0_in & edge_index_1_in

            # subgraph_edge_index = graph.edge_index[:, mask]
            subgraph_x = graph.x[node_indices]
            subgraph_edge_attr = graph.edge_attr[mask]
            subgraph_batch = graph.batch[node_indices]
            # subgraph_z = graph.z[node_indices]

            node_map = {old_idx.item(): new_idx for new_idx, old_idx in enumerate(node_indices)}
            subgraph_edge_index = torch.stack([torch.tensor([node_map[i.item()] for i in graph.edge_index[0, mask]]),
                                               torch.tensor([node_map[i.item()] for i in graph.edge_index[1, mask]])],
                                              dim=0).to(device)
            subgraph_edge_index = subgraph_edge_index.to(torch.long)

            model = model.to(graph.edge_index.device)

            subgraph_pred = model(subgraph_x, subgraph_edge_index, subgraph_edge_attr, subgraph_batch)

            subgraph_node_label = float(subgraph_pred.argmax(dim=1)[0].eq(graph.y[graph_index]))
            graph_node_labels[node_indices] = subgraph_node_label

        pre_node_num = pre_node_num + len(cluster_labels)

    graph.node_labels = graph_node_labels

    return graph


def community_cluster(graph, model):
    adjacency_matrices = build_batch_adj(graph)

    cluster_labels_batch = []
    for i in range(graph.y.size(0)):
        adj = adjacency_matrices[i].to_dense().to(device)

        community_labels = louvain_method(adj.cpu().numpy())
        labels_index = community_labels[0]
        cluster_labels = torch.full((adj.shape[0],), -1, dtype=torch.long)

        for label, node_set in enumerate(labels_index):
            cluster_labels[list(node_set)] = label

        cluster_labels_batch.append(cluster_labels)

    graph_node_labels = torch.full((graph.batch.size(0),), -1).to(device)
    pre_node_num = 0
    for graph_index, cluster_labels in enumerate(cluster_labels_batch):
        n_clusters = torch.max(cluster_labels) + 1
        for i in range(n_clusters):
            node_indices = torch.where(cluster_labels == i)[0]
            node_indices = node_indices.to(graph.edge_index.device)
            node_indices = node_indices + pre_node_num

            edge_index_0_in = torch.isin(graph.edge_index[0], node_indices)
            edge_index_1_in = torch.isin(graph.edge_index[1], node_indices)
            mask = edge_index_0_in & edge_index_1_in

            # subgraph_edge_index = graph.edge_index[:, mask]
            subgraph_x = graph.x[node_indices]
            subgraph_edge_attr = graph.edge_attr[mask]
            subgraph_batch = graph.batch[node_indices]
            # subgraph_z = graph.z[node_indices]

            node_map = {old_idx.item(): new_idx for new_idx, old_idx in enumerate(node_indices)}
            subgraph_edge_index = torch.stack([torch.tensor([node_map[i.item()] for i in graph.edge_index[0, mask]]),
                                               torch.tensor([node_map[i.item()] for i in graph.edge_index[1, mask]])],
                                              dim=0).to(device)
            subgraph_edge_index = subgraph_edge_index.to(torch.long)

            model = model.to(graph.edge_index.device)

            subgraph_pred = model(subgraph_x, subgraph_edge_index, subgraph_edge_attr, subgraph_batch)

            subgraph_node_label = float(subgraph_pred.argmax(dim=1)[0].eq(graph.y[graph_index]))
            graph_node_labels[node_indices] = subgraph_node_label

        pre_node_num = pre_node_num + len(cluster_labels)

    graph.node_labels = graph_node_labels

    return graph


# for graph in train_loader:
#     graph = graph.to(device)
#     # print(community_cluster(graph, model))
#     print(spectral_cluster(graph, model, n_clusters=2))

