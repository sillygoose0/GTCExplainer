import torch
import random
import copy
import numpy as np

from torch import nn
import torch.nn.functional as F
from tqdm import tqdm

from utils.reorganizer import relabel_graph

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def set_seed(seed):
    random.seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


def graph_train(train_loader, model, optimizer, criterion=nn.MSELoss):
    model.train()
    loss_all = 0
    criterion = criterion

    for data in train_loader:
        data.to(device)
        optimizer.zero_grad()

        out = model(data.x, data.edge_index, data.edge_attr, data.batch)

        loss = criterion(out, data.y)
        loss.backward()
        loss_all += loss.item() * data.num_graphs
        optimizer.step()  # 通过优化器更新模型参数

    return loss_all / len(train_loader.dataset)


def graph_test(test_loader, model, criterion=nn.L1Loss(reduction='mean')):
    model.eval()
    error = 0
    correct = 0

    with torch.no_grad():
        for data in test_loader:
            data = data.to(device)

            output = model(data.x, data.edge_index, data.edge_attr, data.batch)

            error += criterion(output, data.y) * data.num_graphs
            correct += float(output.argmax(dim=1).eq(data.y).sum().item())

        return error / len(test_loader.dataset), correct / len(test_loader.dataset)


def find_opp_sub(graph, selection):
    subgraph = copy.deepcopy(graph)
    opp_subgraph = copy.deepcopy(graph)
    subgraph.edge_index = graph.edge_index.T[selection].T
    sub_nodes = torch.unique(subgraph.edge_index)

    graph_nodes = torch.arange(graph.x.size(0)).to(device)
    nodes_mask = torch.isin(graph_nodes, sub_nodes)
    opp_nodes = graph_nodes[~nodes_mask]

    row, col = graph.edge_index
    edge_mask = torch.zeros(graph.edge_index.size(1), dtype=torch.bool, device=row.device)
    for i in range(graph.edge_index.size(1)):
        if row[i] in opp_nodes and col[i] in opp_nodes:
            edge_mask[i] = True

    opp_subgraph.edge_index = graph.edge_index.T[edge_mask].T
    opp_subgraph.edge_attr = graph.edge_attr[edge_mask]
    opp_subgraph.x = graph.x[opp_nodes]
    opp_subgraph.batch = graph.batch[opp_nodes]

    unique_numbers = torch.unique(opp_subgraph.batch)
    numbers_to_new_index = {value.item(): idx for idx, value in enumerate(unique_numbers)}
    opp_subgraph.batch = torch.tensor([numbers_to_new_index[val.item()] for val in opp_subgraph.batch],
                                      device=opp_subgraph.batch.device)

    node_index = row.new_full((graph.num_nodes,), -1)
    node_index[opp_nodes] = torch.arange(opp_nodes.size(0), device=row.device)
    opp_subgraph.edge_index = node_index[opp_subgraph.edge_index]

    return opp_subgraph

# def find_opp_sub(graph, selection):
#     selection = ~selection
#     opp_subgraph = copy.deepcopy(graph)
#
#     opp_subgraph.edge_index = graph.edge_index.T[selection].T
#     opp_subgraph.edge_attr = graph.edge_attr[selection]
#
#     opp_sub_nodes = torch.unique(opp_subgraph.edge_index)
#     opp_subgraph.x = graph.x[opp_sub_nodes]
#     opp_subgraph.batch = graph.batch[opp_sub_nodes]
#
#     unique_numbers = torch.unique(opp_subgraph.batch)
#     numbers_to_new_index = {value.item(): idx for idx, value in enumerate(unique_numbers)}
#     opp_subgraph.batch = torch.tensor([numbers_to_new_index[val.item()] for val in opp_subgraph.batch],
#                                       device=opp_subgraph.batch.device)
#
#     row, col = graph.edge_index
#     node_index = row.new_full((graph.num_nodes, ), -1)
#     node_index[opp_sub_nodes] = torch.arange(opp_sub_nodes.size(0), device=row.device)
#     opp_subgraph.edge_index = node_index[opp_subgraph.edge_index]
#
#     return opp_subgraph


def evaluate_metrics(explainer, model, test_loader):
    explainer.eval()
    model.eval()

    top_k_ratio_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

    acc_count_list = np.zeros(10)
    fid_count_list = np.zeros(9)
    infid_count_list = np.zeros(9)

    num_graph = 0
    num_positive = 0
    with torch.no_grad():
        for graph in tqdm(iter(test_loader)):
            graph = graph.to(device)
            num_graph += len(graph)
            num_positive += torch.sum(graph.y == 1).item()
            max_budget = int(graph.num_edges / num_graph)
            state = torch.zeros(graph.num_edges, dtype=torch.bool)

            check_budget_list = [max(int(_top_k * max_budget), 1) for _top_k in top_k_ratio_list]
            valid_budget = max(int(0.9 * max_budget), 1)

            # pre_probs = torch.empty(0, 0)
            for budget in range(valid_budget):

                available_actions = state[~state].clone()

                _, make_action_probs, make_action_id, _ = explainer.forward_pro(graph=graph, state=state,
                                                                                train_flag=False)

                available_actions[make_action_id] = True
                state[~state] = available_actions.clone()

                if (budget + 1) in check_budget_list:
                    check_idx = check_budget_list.index(budget + 1)

                    ori_pred = model(graph.x, graph.edge_index, graph.edge_attr, graph.batch)
                    ori_probs = F.softmax(ori_pred, dim=1)

                    subgraph = relabel_graph(graph, state)
                    subgraph_pred = model(subgraph.x, subgraph.edge_index, subgraph.edge_attr, subgraph.batch)
                    subgraph_probs = F.softmax(subgraph_pred, dim=1)

                    opp_subgraph = find_opp_sub(graph, state)
                    opp_subgraph_pred = model(opp_subgraph.x, opp_subgraph.edge_index,
                                              opp_subgraph.edge_attr, opp_subgraph.batch)
                    opp_subgraph_probs = F.softmax(opp_subgraph_pred, dim=1)

                    if len(opp_subgraph_probs) < len(graph.y):
                        all_numbers = torch.arange(0, len(graph.y)).to(device)
                        unique_numbers = torch.unique(opp_subgraph.batch)
                        mask = torch.isin(all_numbers, unique_numbers)
                        missing_numbers = all_numbers[~mask]

                        opp_subgraph_probs_list = opp_subgraph_probs.tolist()
                        for idx in sorted(missing_numbers.tolist(), reverse=True):
                            opp_subgraph_probs_list.insert(idx, [0.0, 0.0])
                        opp_subgraph_probs = torch.tensor(opp_subgraph_probs_list).to(device)

                    ori_probs = ori_probs.gather(1, graph.y.view(-1, 1))
                    subgraph_probs = subgraph_probs.gather(1, graph.y.view(-1, 1))
                    opp_subgraph_probs = opp_subgraph_probs.gather(1, graph.y.view(-1, 1))

                    acc_count_list[check_idx] += (graph.y == subgraph_pred.argmax(dim=1)).sum().item()
                    # fid_count_list[check_idx] += (ori_probs - opp_subgraph_probs).sum()
                    # infid_count_list[check_idx] += (ori_probs - subgraph_probs).sum()
                    fid_count_list[check_idx] += torch.matmul((ori_probs - opp_subgraph_probs).float().squeeze(1), graph.y.float())
                    infid_count_list[check_idx] += torch.matmul((ori_probs - subgraph_probs).float().squeeze(1), graph.y.float())

    acc_count_list[-1] = num_graph

    acc_count_list = np.array(acc_count_list) / num_graph
    # fid_count_list = np.array(fid_count_list) / num_graph
    # infid_count_list = np.array(infid_count_list) / num_graph
    fid_count_list = np.array(fid_count_list) / num_positive
    infid_count_list = np.array(infid_count_list) / num_positive

    print(acc_count_list)
    print(fid_count_list)
    print(infid_count_list)

    return np.array(acc_count_list), np.array(fid_count_list), np.array(infid_count_list)











