import os
import os.path as osp

import torch
import torch.nn.functional as F
import random
import numpy as np
import sklearn.preprocessing as preprocessing
from torch_geometric.data import InMemoryDataset, download_url, extract_zip, Data


class Tox21(InMemoryDataset):

    splits = ['training', 'evaluation', 'testing']

    def __init__(self, root, mode='', transform=None, pre_transform=None, pre_filter=None):
        assert mode in self.splits
        self.mode = mode
        super(Tox21, self).__init__(root, transform, pre_transform, pre_filter)

        # self.process()

        idx = self.processed_file_names.index('{}.pt'.format(mode))
        self.data, self.slices = torch.load(self.processed_paths[idx])

    def __repr__(self):
        return "Tox21"

    @property
    def raw_file_names(self):
        if self.mode == 'training':
            return ['Tox21_AhR_training/' + i \
                    for i in [
                        'Tox21_AhR_training_A.txt',
                        'Tox21_AhR_training_edge_labels.txt',
                        'Tox21_AhR_training_graph_indicator.txt',
                        'Tox21_AhR_training_graph_labels.txt',
                        'Tox21_AhR_training_node_labels.txt',
                    ]
                    ]
        if self.mode == 'evaluation':
            return ['Tox21_AhR_evaluation/' + i \
                    for i in [
                        'Tox21_AhR_evaluation_A.txt',
                        'Tox21_AhR_evaluation_edge_labels.txt',
                        'Tox21_AhR_evaluation_graph_indicator.txt',
                        'Tox21_AhR_evaluation_graph_labels.txt',
                        'Tox21_AhR_evaluation_node_labels.txt',
                    ]
                    ]
        if self.mode == 'testing':
            return ['Tox21_AhR_testing/' + i \
                    for i in [
                        'Tox21_AhR_testing_A.txt',
                        'Tox21_AhR_testing_edge_labels.txt',
                        'Tox21_AhR_testing_graph_indicator.txt',
                        'Tox21_AhR_testing_graph_labels.txt',
                        'Tox21_AhR_testing_node_labels.txt',
                    ]
                    ]

    @property
    def processed_file_names(self):
        return ['training.pt', 'evaluation.pt', 'testing.pt']

    def process(self):

        edge_index = np.loadtxt(osp.join(self.raw_dir, self.raw_file_names[0]), delimiter=',').T
        edge_index = torch.from_numpy(edge_index - 1).to(torch.long)

        edge_labels = np.loadtxt(osp.join(self.raw_dir, self.raw_file_names[1]))
        encoder = preprocessing.OneHotEncoder().fit(np.unique(edge_labels).reshape(-1, 1))
        edge_attr = encoder.transform(edge_labels.reshape(-1, 1)).toarray()
        edge_attr = torch.Tensor(edge_attr)
        # edge_attr = torch.Tensor(edge_labels)

        node_labels = np.loadtxt(osp.join(self.raw_dir, self.raw_file_names[-1]))
        encoder = preprocessing.OneHotEncoder().fit(np.unique(node_labels).reshape(-1, 1))
        x = encoder.transform(node_labels.reshape(-1, 1)).toarray()
        x = torch.Tensor(x)

        z = np.loadtxt(osp.join(self.raw_dir, self.raw_file_names[2]), dtype=int)

        y = np.loadtxt(osp.join(self.raw_dir, self.raw_file_names[3]))
        y = torch.unsqueeze(torch.LongTensor(y), 1).long()

        num_graphs = len(y)
        total_edges = edge_index.size(1)
        begin = 0

        if self.mode == 'training':
            assert x.size(1) == 50
        if self.mode == 'evaluation':
            assert x.size(1) == 25
            x = F.pad(x, (0, 25))
        if self.mode == 'testing':
            assert x.size(1) == 15
            x = F.pad(x, (0, 35))

        data_list = []
        num = 0
        for i in range(num_graphs):

            perm = np.where(z == i+1)[0]  # 确定第i+1个图的节点索引
            bound = max(perm)  # 确定第i个图的边界
            end = begin
            # 找到第一个不属于图i的边，使end指向该边
            for end in range(begin, total_edges):
                if int(edge_index[0, end]) > bound:
                    break

            data = Data(x=x[perm],  # 节点特征矩阵x
                        y=y[i],  # 图标签
                        z=node_labels[perm],  # 节点标签
                        edge_index=edge_index[:, begin:end] - int(min(perm)),  # 边索引
                        edge_attr=edge_attr[begin:end],  # 边属性
                        name="tox21_%d" % i,  # 图名称
                        idx=i)

            if self.pre_filter is not None and not self.pre_filter(data):
                continue
            if self.pre_transform is not None:
                data = self.pre_transform(data)

            begin = end
            if data.edge_index.shape[1] > 0:
                data_list.append(data)
            else:
                num = num + 1

        if self.mode == 'training':
            assert len(data_list) == (8169 - num)
            torch.save(self.collate(data_list), self.processed_paths[0])
        if self.mode == 'evaluation':
            assert len(data_list) == (607 - num)
            torch.save(self.collate(data_list), self.processed_paths[1])
        if self.mode == 'testing':
            assert len(data_list) == (272 - num)
            torch.save(self.collate(data_list), self.processed_paths[2])

