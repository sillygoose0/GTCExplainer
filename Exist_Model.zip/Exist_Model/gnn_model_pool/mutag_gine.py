import argparse
import random
import time
import os

import torch
import torch.nn
from torch.nn import ModuleList
from torch.nn import Linear, ReLU, Sequential, Softmax
from torch.optim.lr_scheduler import ReduceLROnPlateau

from torch_geometric.nn.conv import GINEConv, GINConv, GCNConv
# from torch_geometric.graphgym.models.layer import GINConv, LayerConfig

from torch_geometric.nn.norm.batch_norm import BatchNorm
from torch_geometric.nn.pool.glob import global_mean_pool
from torch_geometric.loader.dataloader import DataLoader

from utils import set_seed, graph_train, graph_test
from Exist_Model.data_loader_pool.muatg_dataloader import Mutagen

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def par_args():
    parser = argparse.ArgumentParser(description="Train Mutag Model")

    parser.add_argument('--data_path', nargs='?', default='../Data/MUTAG',
                        help='Input data path.')
    parser.add_argument('--model_path', nargs='?', default='../params/',
                        help='path of saving trained model.')
    parser.add_argument('--epoch', type=int, default=300,
                        help='Number of epoch.')
    parser.add_argument('--lr', type=float, default=1e-3,
                        help='Learning rate.')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='Batch size.')
    parser.add_argument('--verbose', type=int, default=10,
                        help='Interval of evaluation.')
    parser.add_argument('--num_unit', type=int, default=2,
                        help='number of Convolution layers(units).')
    parser.add_argument('--random_label', type=bool, default=False,
                        help='train a model under label randomization for sanity check.')
    return parser.parse_args()


class MutagNet(torch.nn.Module):

    def __init__(self, conv_unit=2):
        super(MutagNet, self).__init__()

        self.node_emb = Linear(14, 32)
        self.edge_emb = Linear(3, 32)
        self.relu_nn = ModuleList([ReLU() for i in range(conv_unit)])

        self.convs = ModuleList()
        self.batch_norms = ModuleList()
        self.relus = ModuleList()

        for i in range(conv_unit):
            conv = GINEConv(nn=Sequential(Linear(32, 75), self.relu_nn[i], Linear(75, 32)))
            self.convs.append(conv)
            self.batch_norms.append(BatchNorm(32))
            self.relus.append(ReLU())

        self.lin1 = Linear(32, 14)
        self.relu = ReLU()
        self.lin2 = Linear(14, 2)
        self.softmax = Softmax(dim=1)
        self.readout = None

    def get_node_reps(self, x, edge_index, edge_attr, batch):
        node_x = self.node_emb(x)
        edge_attr = self.edge_emb(edge_attr)

        for conv, batchNorm, relu in zip(self.convs, self.batch_norms, self.relus):
            node_x = conv(node_x, edge_index, edge_attr)
            node_x = relu(batchNorm(node_x))

        return node_x

    def get_graph_reps(self, x, edge_index, edge_attr, batch):
        node_x = self.get_node_reps(x, edge_index, edge_attr, batch)
        graph_x = global_mean_pool(node_x, batch)
        return graph_x

    def get_pred(self, graph_x):
        pred = self.relu(self.lin1(graph_x))
        pred = self.lin2(pred)
        self.readout = self.softmax(pred)
        return pred

    # def get_pred(self, graph_x):
    #     pred = graph_x
    #     self.readout = self.softmax(pred)
    #     return self.readout

    def forward(self, x, edge_index, edge_attr, batch):
        graph_x = self.get_graph_reps(x, edge_index, edge_attr, batch)
        forward_x = self.get_pred(graph_x)
        return forward_x

    def reset_parameters(self):
        with torch.no_grad():
            for param in self.parameters():
                param.uniform_(-1.0, 1.0)


if __name__ == '__main__':
    args = par_args()
    set_seed(0)

    train_dataset = Mutagen('../../Data/MUTAG', mode='training')
    test_dataset = Mutagen('../../Data/MUTAG', mode='testing')
    val_dataset = Mutagen('../../Data/MUTAG', mode='evaluation')

    # 将标签随机化，以便评估模型在没有真实标签的情况下的表现
    if args.random_label:
        for dataset in [train_dataset, test_dataset, val_dataset]:
            for g in dataset:
                g.y.fill_(random.choice([0, 1]))

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)

    model = MutagNet(args.num_unit).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=10, min_lr=1e-4)

    min_error = None

    for epoch in range(1, args.epoch+1):
        t1 = time.time()
        lr = scheduler.optimizer.param_groups[0]['lr'] * 10

        loss = graph_train(train_loader, model, optimizer, criterion=torch.nn.CrossEntropyLoss())

        train_error, train_acc = graph_test(train_loader, model, criterion=torch.nn.CrossEntropyLoss())

        test_error, test_acc = graph_test(test_loader, model, criterion=torch.nn.CrossEntropyLoss())

        val_error, val_acc = graph_test(val_loader, model, criterion=torch.nn.CrossEntropyLoss())

        scheduler.step(val_error)
        if min_error is None or val_error <= min_error:
            min_error = val_error

        t2 = time.time()

        if epoch % args.verbose == 0:
            test_error, test_acc = graph_test(test_loader, model, criterion=torch.nn.CrossEntropyLoss())

            t3 = time.time()

            print('Epoch{:4d}[{:.3f}s]: LR: {:.5f}, Loss: {:.5f}, Test Loss: {:.5f}, '
                  'Test acc: {:.5f}'.format(epoch, t3 - t1, lr, loss, test_error, test_acc))
            continue

        print('Epoch{:4d}[{:.3f}s]: LR: {:.5f}, Loss: {:.5f}, Train acc: {:.5f}, Validation Loss: {:.5f},'
              'Validation acc: {:5f}'.format(epoch, t2 - t1, lr, loss, train_acc, val_error, val_acc))

        # torch.cuda.empty_cache()

    if args.random_label:
        save_path = '/tmp/Explainer/params/mutag_net_GCNConv_rd.pt'
    else:
        save_path = '/tmp/Explainer/params/mutag_net_GCNConv.pt'
    torch.save(model, save_path)

# Epoch 299[1.374s]: LR: 0.00100, Loss: 0.28868, Train acc: 0.88493, Validation Loss: 0.45161,Validation acc: 0.834000
# Epoch 300[1.576s]: LR: 0.00100, Loss: 0.28681, Test Loss: 0.41065, Test acc: 0.81000












